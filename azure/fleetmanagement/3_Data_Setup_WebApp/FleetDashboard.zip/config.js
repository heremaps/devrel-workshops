var config = {}

config.endpoint = ""; //Cosmos_DB_URI
config.primaryKey = ""; //Cosmos_DB_PRIMARY_KEY






config.database = {
    "id": "HERE_API_LOGS"
};

config.container = {
    "id": "here_api_logs"
};



module.exports = config;