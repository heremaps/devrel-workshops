// Read Kinesis Data Stream => Get Lat & Long => GeoCode => Store in Dynamo DB

'use strict';

const AWS = require('aws-sdk');

const dynamoDB = new AWS.DynamoDB.DocumentClient();
const tableName = process.env.TABLE_NAME;
const request = require('request');

exports.handler = function(event, context, callback) {
  Promise.all(buildRequestItems(event.Records))
    .then(requestItems => {
      const requests = buildRequests(requestItems);
      Promise.all(requests)
        .then(() => callback(null, `Delivered ${event.Records.length} records`))
        .catch(callback);
    })
    .catch(callback);
};

function buildRequestItems(records) {
  return records.map(record => {
    const json = Buffer.from(record.kinesis.data, 'base64').toString('ascii');
    const item = JSON.parse(json);
    // retrieving Latitude & Longitue
    let latlong = item['Latitude'] + ',' + item['Longitude'];

    // Invoking lambda function API endpoint
    let url = 'https://6i5z73t678.execute-api.us-east-1.amazonaws.com/Test/geocode/'; // https://xx22yyxwe9.execute-api.eu-west-1.amazonaws.com/Test/geocoder
    var latlonobj = {prox:latlong};

    return new Promise((resolve, reject) => {
      if (latlong != '') {
        request.get({ url: url,qs:latlonobj }, function(err, response, body) {
          if (err) {
            reject(err);
          } // an error occurred
          else {
            let resp = JSON.parse(body);
            let address = resp['Response']['View']['0']['Result']['0']['Location']['Address']['Label'];
            item['Address'] = address;
            resolve({
              PutRequest: {
                Item: item,
              },
            });
          }
        });
      } else {
        reject({ message: 'Lat Long Empty' });
        return false;
      }
    });
  });
}
// push response to dynamo DB
function buildRequests(requestItems) {
  const requests = [];

  while (requestItems.length > 0) {
    const request = batchWrite(requestItems.splice(0, 25));

    requests.push(request);
  }

  return requests;
}

function batchWrite(requestItems, attempt = 0) {
  const params = {
    RequestItems: {
      [tableName]: requestItems,
    },
  };

  let delay = 0;

  if (attempt > 0) {
    delay = 50 * Math.pow(2, attempt);
  }

  return new Promise(function(resolve, reject) {
    setTimeout(function() {
      dynamoDB
        .batchWrite(params)
        .promise()
        .then(function(data) {
          if (data.UnprocessedItems.hasOwnProperty(tableName)) {
            return batchWrite(data.UnprocessedItems[tableName], attempt + 1);
          }
        })
        .then(resolve)
        .catch(reject);
    }, delay);
  });
}
